﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice.Class.WeiXinMenu
{
    class MenuKind
    {
    }
}
