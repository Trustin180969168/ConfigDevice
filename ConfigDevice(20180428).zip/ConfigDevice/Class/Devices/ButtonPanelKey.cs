﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace ConfigDevice
{
    public class ButtonPanelKey : Device
    {
        public KeyCircuit Circuit;//回路对象
        public ButtonPanelCtrl PanelCtrl;//按键对象


        public ButtonPanelKey(UserUdpData userUdpData)
            : base(userUdpData)
        {
            initControlObjs();
        }

        public ButtonPanelKey(DeviceData data)
            : base(data)
        {
            initControlObjs();
        }

        public ButtonPanelKey(DataRow dr)
            : base(dr)
        {
            initControlObjs();
        }

        /// <summary>
        /// 初始化控制对象
        /// </summary>
        private void initControlObjs()
        {
            Circuit = new KeyCircuit(this, 2);//---默认两个回路
            PanelCtrl = new ButtonPanelCtrl(this);
            ContrlObjs.Add(DeviceConfig.CONTROL_OBJECT_CIRCUIT_NAME, this.Circuit); 
        }

 

    }


}
