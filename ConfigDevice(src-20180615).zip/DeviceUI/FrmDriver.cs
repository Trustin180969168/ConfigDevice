﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ConfigDevice
{
    public partial class FrmDriver : FrmDevice
    {
        private Circuit circuitCtrl;//----回路控制对象----- 
        private DataTable dtCircuit = new DataTable("回路列表选择");
        private GridViewComboBox cbxControlObj;//---下拉选择控制对象--
        private GridViewComboBox cbxControlRoom;//---下拉选择房号-- 
        public FrmDriver(Device _device)
            : base(_device)
        {          
            InitializeComponent();
            this.DeviceEdit.OnCallbackUI_Action += this.callbackUI;//--注册回调事件
            this.DeviceEdit.OnCallbackUI_Action += BaseViewSetting.CallBackUI;//----注册回调事件
            //-----初始化回路选择----  
            dtCircuit.Columns.Add(ViewConfig.DC_ID, System.Type.GetType("System.String"));
            dtCircuit.Columns.Add(ViewConfig.DC_ROOM_NUM, System.Type.GetType("System.String"));//---房号
            dtCircuit.Columns.Add(ViewConfig.DC_CONTROL_OBJ, System.Type.GetType("System.String"));
            dtCircuit.Columns.Add(ViewConfig.DC_NAME, System.Type.GetType("System.String"));
            num.FieldName = ViewConfig.DC_ID;
            name.FieldName = ViewConfig.DC_NAME;
            dcCtrlObj.FieldName = ViewConfig.DC_CONTROL_OBJ;

            //---控制对象 
            cbxControlObj = new GridViewComboBox();
            foreach (string objName in ViewConfig.VIRKEY_TYPE_NAME_ID.Keys)
            {
                cbxControlObj.Items.Add(objName);
            }
            cbxControlObj.DropDownRows = 24;
            dcCtrlObj.ColumnEdit = cbxControlObj;

            circuitCtrl = DeviceEdit.ContrlObjs[DeviceConfig.CONTROL_OBJECT_CIRCUIT_NAME] as Circuit;//获取回路控制对象
            //---房号选择---
            cbxControlRoom = new GridViewComboBox();
            foreach (string roomName in this.circuitCtrl.ListRooms)
            {
                this.cbxControlRoom.Items.Add(roomName);
            }
            cbxControlRoom.DropDownRows = 24;
            dcRoomNum.FieldName = ViewConfig.DC_ROOM_NUM;
            dcRoomNum.ColumnEdit = cbxControlRoom;

            gcCircuit.DataSource = dtCircuit;
        }

        public FrmDriver()
        {
            InitializeComponent();
        }

        private void FrmBaseDevice_Load(object sender, EventArgs e)
        {
            BaseViewSetting.DeviceEdit = this.DeviceEdit;

            BaseViewSetting.DeviceEdit.SearchVer();//---获取版本号-----   
            InitSelectDevice();
            circuitCtrl.ReadRoadTitle();//读取回路列表
        }

        /// <summary>
        /// 回调
        /// </summary>
        private void callbackUI(CallbackParameter callbackParameter)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new CallbackUIAction(callbackUI), callbackParameter);
                }
                else
                {
                    //-----读取完探头参数----- 
                    if (callbackParameter.DeviceID == DeviceEdit.DeviceID && callbackParameter.Action == ActionKind.ReadCircuit)
                    {
                        dtCircuit.Rows.Clear();
                        foreach (int key in circuitCtrl.ListCircuitIDAndName.Keys)
                        {
                            string controlObjName = "";
                            string roomNum = circuitCtrl.ListRooms[circuitCtrl.ListCircuitIDAndRoomID[key]];//---房号
                            if(ViewConfig.VIRKEY_TYPE_ID_NAME.ContainsKey(circuitCtrl.ListCircuitIDAndControlObj[key]))
                            {
                                controlObjName = ViewConfig.VIRKEY_TYPE_ID_NAME[circuitCtrl.ListCircuitIDAndControlObj[key]];
                            }
                            dtCircuit.Rows.Add(key, roomNum, controlObjName, circuitCtrl.ListCircuitIDAndName[key]);
                        }
                        dtCircuit.AcceptChanges();
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// 选择事件
        /// </summary>
        public override void cbxSelectDevice_SelectedIndexChanged(object sender, EventArgs e)
        {

            //this.DeviceEdit.OnCallbackUI_Action -= this.callbackUI;//--退订回调事件
            //this.DeviceEdit.OnCallbackUI_Action -= BaseViewSetting.CallBackUI;//----退订回调事件
            //DeviceData deviceData = new DeviceData(SelectDeviceList[CbxSelectDevice.SelectedIndex]);//设备数据
            //Device DeviceSelect = FactoryDevice.CreateDevice(deviceData.ByteKindID).CreateDevice(deviceData);//--新建同类型设备对象---
            //if (DeviceEdit.MAC == DeviceSelect.MAC) return;

            //BaseViewSetting.DeviceEdit = DeviceSelect;              //---基础配置编辑  
            //DeviceEdit = DeviceSelect;                                 //---父类设备对象-----              
            //circuitCtrl = this.DeviceEdit.ContrlObjs[DeviceConfig.CONTROL_OBJECT_CIRCUIT_NAME] as Circuit;     //获取回路控制对象
            //DeviceEdit.OnCallbackUI_Action += this.callbackUI;          //--注册回调事件
            //DeviceEdit.OnCallbackUI_Action += BaseViewSetting.CallBackUI;//----注册回调事件

            //this.Text = DeviceEdit.Name;                         //----界面标题------
            //BaseViewSetting.DeviceEdit.SearchVer();                 //---获取版本号-----   
            //InitSelectDevice();                                     //---初始化选择设备---
            //circuitCtrl.ReadRoadTitle();                            //读取回路列表
        }

        /// <summary>
        /// 保存回路名称
        /// </summary>
        private void btSave_Click(object sender, EventArgs e)
        {
            gvCircuit.PostEditor();
            DataRow drCurrent = gvCircuit.GetDataRow(gvCircuit.FocusedRowHandle);
            if (drCurrent != null)
                drCurrent.EndEdit();
            DataTable dtModify = dtCircuit.GetChanges(DataRowState.Modified);
            if (dtModify == null) return;
            foreach (DataRow dr in dtModify.Rows)
            {
                int changeID = Convert.ToInt16(dr[ViewConfig.DC_ID]);
                string roomName = dr[ViewConfig.DC_ROOM_NUM].ToString();
                circuitCtrl.ListCircuitIDAndRoomID[changeID] = circuitCtrl.ListRooms.IndexOf(roomName);
                string controlObjName = dr[ViewConfig.DC_CONTROL_OBJ].ToString();
                int controlObjId = 0;
                if (ViewConfig.VIRKEY_TYPE_NAME_ID.ContainsKey(controlObjName))
                    controlObjId = ViewConfig.VIRKEY_TYPE_NAME_ID[controlObjName];
                string changeName = dr[ViewConfig.DC_NAME].ToString();
                circuitCtrl.SaveRoadSetting(changeID - 1, controlObjName, changeName);
            } 
            dtModify.AcceptChanges();//---提交修改---
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btRefresh_Click(object sender, EventArgs e)
        {
            circuitCtrl.ReadRoadTitle();//读取回路列表
        }

        private void gcCircuit_Click(object sender, EventArgs e)
        {

        }


    }


}
