﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice
{
    class DeviceWeatherStation:DeviceData
    {

        public DeviceWeatherStation(UserUdpData userData)
            : base(userData)
        {
           
        }




    }
}
