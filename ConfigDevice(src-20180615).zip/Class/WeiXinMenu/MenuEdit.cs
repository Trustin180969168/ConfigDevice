﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice 
{

    /// <summary>
    /// 菜单编辑
    /// </summary>
    public abstract class MenuEdit
    {
        public abstract void SaveMenu();

    }







}
