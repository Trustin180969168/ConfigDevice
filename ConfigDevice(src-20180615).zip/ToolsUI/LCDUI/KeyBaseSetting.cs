﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ConfigDevice
{
    public partial class KeyBaseSetting : UserControl
    {
        public bool NeedInit = true;
        public KeyList keyList; //---按键列表执行对象----          
        public Circuit KeyCircuit;//---按键回路,由调用者(设备提供)----
        private DataTable dtKeyData;//---按键列表
        private int showCount = 8;//---默认按键个数----
        private int startNum = 0;//---默认开始按键序号为第一个 =0
        private GridViewComboBox cbxControlObj;//---下拉选择控制对象-- 
        private GridViewComboBox cbxControlKind;//---下拉选择控制类型-- 
        private GridViewComboBox cbxControlRoom;//---下拉选择房号-- 
        private BaseKeySettingV2 keySetting;//---按键配置对象---

        /// <summary>
        /// 获取显示按键个数
        /// </summary>
        public int ShowCount
        {
            get { return showCount; }
            set { showCount = value; }
        }
        public KeyBaseSetting()
        {
            InitializeComponent();

            dtKeyData = new DataTable("按键列表");
            cbxControlObj = new GridViewComboBox();//---灯的下拉选择--
            cbxControlKind = new GridViewComboBox();//---类型下拉选择--
            cbxControlRoom = new GridViewComboBox();//---房间号

            dtKeyData.Columns.Add(ViewConfig.DC_NUM, System.Type.GetType("System.Int16"));          //----按键编号
            dtKeyData.Columns.Add(ViewConfig.DC_NAME, System.Type.GetType("System.String"));        //---名称---
            dtKeyData.Columns.Add(ViewConfig.DC_CONTROL_OBJ, System.Type.GetType("System.String")); //---控制对象
            dtKeyData.Columns.Add(ViewConfig.DC_CONTROL_KIND, System.Type.GetType("System.String"));//---控制类型
            dtKeyData.Columns.Add(ViewConfig.DC_ROOM_NUM, System.Type.GetType("System.String"));//---房号
            dtKeyData.Columns.Add(ViewConfig.DC_COMMUNICATE_KIND, System.Type.GetType("System.String"));//---通讯模式
            dtKeyData.Columns.Add(ViewConfig.DC_DIRECTION_MAX, System.Type.GetType("System.String"));//方向最大值
            dtKeyData.Columns.Add(ViewConfig.DC_DIRECTION_MIN, System.Type.GetType("System.String"));//方向最小值
            dtKeyData.Columns.Add(ViewConfig.DC_DIRECTION_STEP, System.Type.GetType("System.String")); //方向步进
            dtKeyData.Columns.Add(ViewConfig.DC_RELEVANCE_NUM, System.Type.GetType("System.String"));//关联号
            dtKeyData.Columns.Add(ViewConfig.DC_MUTEX_NUM, System.Type.GetType("System.String"));   //互斥号 

            dcNum.FieldName = ViewConfig.DC_NUM;
            dcName.FieldName = ViewConfig.DC_NAME;
            dcCtrlObj.FieldName = ViewConfig.DC_CONTROL_OBJ;
            dcCtrlKind.FieldName = ViewConfig.DC_CONTROL_KIND;
            dcRoomNum.FieldName = ViewConfig.DC_ROOM_NUM;
            dcComunication.FieldName = ViewConfig.DC_COMMUNICATE_KIND;
            dcDectMax.FieldName = ViewConfig.DC_DIRECTION_MAX;
            dcDectMin.FieldName = ViewConfig.DC_DIRECTION_MIN;
            dcStep.FieldName = ViewConfig.DC_DIRECTION_STEP;
            dcRelevance.FieldName = ViewConfig.DC_RELEVANCE_NUM;
            dcMutex.FieldName = ViewConfig.DC_MUTEX_NUM;


        }

        /// <summary>
        /// 初始化配置按键配置列表
        /// </summary>
        /// <param name="deviceControled">设备对象</param>
        /// <param name="_showCount">显示个数</param>
        /// <param name="deviceControled">分页标题</param>
        public void InitKeySettingList(Device deviceControled, int _startNum, int _showCount)
        {
            showCount = _showCount;
            startNum = _startNum;

            keySetting = new BaseKeySettingV2(gvKeyData);//---按键配置对象---
            keyList = new KeyList(deviceControled);
            keyList.OnCallbackUI_Action += this.ReturnKeyData;
            //---控制对象
            foreach (string name in ViewConfig.VIRKEY_TYPE_NAME_ID.Keys)
            {
                cbxControlObj.Items.Add(name);
            } 
            cbxControlObj.DropDownRows = 24;
            dcCtrlObj.ColumnEdit = cbxControlObj; 
            //---控制类型
            cbxControlKind.Items.Add(ViewConfig.KEY_CONTROL_KIND_NAME_OPEN_CLOSE);
            cbxControlKind.Items.Add(ViewConfig.KEY_CONTROL_KIND_NAME_OPEN);
            cbxControlKind.Items.Add(ViewConfig.KEY_CONTROL_KIND_NAME_CLOSE);
            cbxControlKind.Items.Add(ViewConfig.KEY_CONTROL_KIND_NAME_OPEN_CLOSE_LOOP_LIGHT);
            cbxControlKind.Items.Add(ViewConfig.KEY_CONTROL_KIND_NAME_OPEN_LOOP_LIGHT);
            cbxControlKind.DropDownRows = 8;
            dcCtrlKind.ColumnEdit = cbxControlKind;  

            gcKeyData.DataSource = dtKeyData;
            KeyCircuit = deviceControled.ContrlObjs[DeviceConfig.CONTROL_OBJECT_CIRCUIT_NAME] as Circuit;
            KeyCircuit.OnCallbackUI_Action +=  ReturnKeyName;
            //---房号选择---
            foreach (string name in this.KeyCircuit.ListRooms)
            {
                this.cbxControlRoom.Items.Add(name);
            }
            cbxControlRoom.DropDownRows = 24;
            dcRoomNum.ColumnEdit = cbxControlRoom;
         
        }

        void cbxControlObj_EditValueChanged(object sender, EventArgs e)
        {
            //gvKeyData.PostEditor();
            //DataRow dr = gvKeyData.GetDataRow(gvKeyData.FocusedRowHandle);
            //if (dr != null)
            //{
            //    dr.EndEdit();
            //    string controlObj = dr[dcCtrlObj.FieldName].ToString();
            //    //if (controlObj == ViewConfig.KEY_TYPE_NAME_LIGHT)
            //    //    dcCtrlKind.ColumnEdit = cbxLightControlKind;
            //    //else
            //    //    dcCtrlKind.ColumnEdit = cbxElseControlKind;
            //    dcCtrlKind.ColumnEdit = cbxLightControlKind;
            //}
        }



        /// <summary>
        /// 读取并显示按键数据
        /// </summary>
        public void ReturnKeyData(CallbackParameter parameter)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new CallbackUIAction(ReturnKeyData), parameter);
                return;
            }
            KeyData keyData = parameter.Parameters[0] as KeyData;
            int index = keyData.KeyNum % 8;

            while (dtKeyData.Rows.Count < index + 1)
                dtKeyData.Rows.Add(index + 1);

            DataRow dr = gvKeyData.GetDataRow(index);//---获取分页的对应行
            if (dr != null)
            {
                keySetting.SetKeyData(keyData, dr);//---赋值到行---- 

                //----添加名称------- 
                dr[ViewConfig.DC_NAME] = KeyCircuit.ListCircuitIDAndName[keyData.KeyNum + 1];
                dr[ViewConfig.DC_ROOM_NUM] = KeyCircuit.ListRooms[KeyCircuit.ListCircuitIDAndRoomID[keyData.KeyNum + 1]];//---房号
                int controlObjId = KeyCircuit.ListCircuitIDAndControlObj[keyData.KeyNum + 1];
                if (ViewConfig.VIRKEY_TYPE_ID_NAME.ContainsKey(controlObjId))
                {
                    dr[ViewConfig.DC_CONTROL_OBJ] = ViewConfig.VIRKEY_TYPE_ID_NAME[controlObjId];
            
                }

                dr.AcceptChanges();

                gvKeyData.RefreshData();
                gvKeyData.BestFitColumns();

   
            }
        }

        /// <summary>
        /// 读取并显示按键名称
        /// </summary>
        public void ReturnKeyName(CallbackParameter parameter)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new CallbackUIAction(ReturnKeyName), parameter);
                return;
            }
            else
            {
                if (parameter.Parameters != null && parameter.DeviceID == keyList.device.DeviceID &&
                    parameter.Action == ActionKind.ReadCircuit)//---回路名称--
                {
                    NeedInit = false;//----回路读取完毕为初始化完毕----     
                    int i = 1;
                    foreach (DataRow dr in dtKeyData.Rows)
                    {
                        dr[ViewConfig.DC_NAME] = KeyCircuit.ListCircuitIDAndName[this.startNum + i];
                        dr[ViewConfig.DC_ROOM_NUM] = KeyCircuit.ListRooms[KeyCircuit.ListCircuitIDAndRoomID[this.startNum + i]];//---房号
                        int controlObjId = KeyCircuit.ListCircuitIDAndControlObj[this.startNum + i];
                        if (ViewConfig.VIRKEY_TYPE_ID_NAME.ContainsKey(controlObjId))
                        {
                            dr[ViewConfig.DC_CONTROL_OBJ] = ViewConfig.VIRKEY_TYPE_ID_NAME[controlObjId];
                        }
                        i++;
                    }
                    dtKeyData.AcceptChanges();
                    gvKeyData.RefreshData();
                    gvKeyData.BestFitColumns();
                }
            }
        }

        /// <summary>
        /// 刷新数据
        /// </summary>
        public void RefreshData()
        {
            ReadKeyData();
        }

        /// <summary>
        /// 申请读取按键配置
        /// </summary>
        /// <param name="startKey">开始按键</param>
        /// <param name="endKey">结束按键</param>
        public void ReadKeyData()
        {
            dtKeyData.Rows.Clear();
            keyList.ReadKeyData(startNum, startNum + showCount - 1);//---读取按键配置----
        }

        /// <summary>
        /// 保存按键配置
        /// </summary>
        public void SaveKeyData()
        {
            gvKeyData.PostEditor();
            DataRow drCurrent = gvKeyData.GetDataRow(gvKeyData.FocusedRowHandle);
            if (drCurrent != null)
                drCurrent.EndEdit();

            DataTable dtModify = dtKeyData.GetChanges(DataRowState.Modified);
            if (dtModify == null) return;
            //----保存配置信息------
            foreach (DataRow dr in dtModify.Rows)
                keyList.SaveKeyData(keySetting.GetKeyData(dr));
            //----保存名称-----
            foreach (DataRow dr in dtModify.Rows)
            {
                int changeID = Convert.ToInt16(dr[ViewConfig.DC_NUM]);
                string roomName = dr[ViewConfig.DC_ROOM_NUM].ToString();
                KeyCircuit.ListCircuitIDAndRoomID[changeID] = KeyCircuit.ListRooms.IndexOf(roomName);
                string changeName = dr[ViewConfig.DC_NAME].ToString();
                string changeControlObj = dr[ViewConfig.DC_CONTROL_OBJ].ToString();
                int controlObjId = 0;
                if (ViewConfig.VIRKEY_TYPE_NAME_ID.ContainsKey(changeControlObj))
                    controlObjId = ViewConfig.VIRKEY_TYPE_NAME_ID[changeControlObj];
                KeyCircuit.SaveKeyRoadSetting(changeID - 1, changeName, controlObjId);//--保存回路名称---
            }
            dtKeyData.AcceptChanges();
        }

        /// <summary>
        /// 切换控制类型编辑
        /// </summary>
        private void gvKeyData_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
 
        }

    }
}
