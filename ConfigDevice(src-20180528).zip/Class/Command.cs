﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice
{
    class Command
    {


    }
}
