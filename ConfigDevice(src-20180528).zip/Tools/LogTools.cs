﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice
{
    public class LogTools
    {
        /// <summary>
        /// 写日志信息
        /// </summary>
        /// <param name="msg"></param>
        public void WriteLog(string msg)
        {

        }



        /// <summary>
        /// 写日志信息
        /// </summary>
        /// <param name="msg"></param>
        public void DeleteLog(DateTime date)
        {

        }



    }
}
