﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigDevice
{
    class DeviceAmplifier:DeviceData
    {

        public DeviceAmplifier(UserUdpData userData): base(userData)
        {
           
        }





    }
}
